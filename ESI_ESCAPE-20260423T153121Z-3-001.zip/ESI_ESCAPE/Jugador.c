/*
 * Modulo   : Jugador.c
 * Proyecto : ESI-Escape
 * Descripcion: Implementacion del modulo de gestion de jugadores del juego.
 *              Proporciona operaciones para inicializar, autenticar, registrar
 *              y gestionar el inventario y movimiento de los jugadores.
 *
 * Autores  : Juan Rojas Baldrich, Marc Garrote Palmer, Lucas Letran Rivero
 * Asignatura: Metodologia de la Programacion
 */

#include <stdio.h>
#include <string.h>

#include "Jugador.h"

/* =========================================================
 * Busqueda y autenticacion
 * ========================================================= */

/*
 * Funcion    : buscarJugador
 * Descripcion: Recorre la lista buscando el jugador cuyo campo usuario
 *              coincide con el parametro.
 * Retorno    : Indice del jugador si lo encuentra; -1 en caso contrario.
 */
int buscarJugador(Jugador** lista, int num, char* usuario) {
    for (int i = 0; i < num; i++) {
        if (strcmp(lista[i]->Jugador, usuario) == 0) { // Acceso con ->
            return i;
        }
    }
    return -1;
}
/* =========================================================
 * Registro
 * ========================================================= */

/*
 * Funcion    : registrarJugador
 * Descripcion: A�ade un nuevo jugador al final de la lista incrementando
 *              numJugadores.
 * Retorno    : El puntero al array de jugadores actualizado.
 */
Jugador** registrarJugador(Jugador** lista, int* num_jugadores, Jugador* nuevo_jugador) {
    lista = realloc(lista, (*num_jugadores + 1) * sizeof(Jugador*));

    if (lista == NULL) {
        printf("Error: No se pudo reservar memoria para registrar al nuevo jugador.\n");
        return NULL;
    }
    lista[*num_jugadores] = nuevo_jugador;
    (*num_jugadores)++;
    return lista;
}

/* =========================================================
 * Movimiento
 * ========================================================= */

/*
 * Funcion    : moverJugadorASala
 * Descripcion: Actualiza el campo salaActual del jugador con el
 *              identificador de sala indicado.
 */
void actualizarPosicionJugador(Partida *p_actual, int nueva_sala) {
    if (p_actual != NULL) {
        p_actual->id_sala_actual = nueva_sala;
    }
}

/* =========================================================
 * Gestion del inventario
 * ========================================================= */

/*
 * Funcion    : agregarObjetoInventario
 * Descripcion: Agrega el identificador de un objeto al inventario del
 *              jugador si no esta lleno.
 * Retorno    : 1 si se pudo anadir; 0 si el inventario esta lleno.
 */
int agregarObjetoInventario(Jugador* j, char* idObj) {
    // Realloc para el array de punteros char**
    j->Inventario = realloc(j->Inventario, (j->Num_objetos + 1) * sizeof(char*));
    j->Inventario[j->Num_objetos] = malloc(5 * sizeof(char));
    strcpy(j->Inventario[j->Num_objetos], idObj);
    j->Num_objetos++;
    return 1;
}

/*
 * Funcion    : eliminarObjetoInventario
 * Descripcion: Elimina el identificador de un objeto del inventario
 *              desplazando los elementos posteriores para no dejar huecos.
 * Retorno    : 1 si se encontro y elimino; 0 si el objeto no estaba.
 */
int eliminarObjetoInventario(Jugador *jugador, char* idObj) {
    int pos = -1;
    int eliminado = 0;

    // 1. Buscar la posicion del objeto
    for (int i = 0; i < jugador->Num_objetos; i++) {
        if (strcmp(jugador->Inventario[i], idObj) == 0) {
            pos = i;
            break; // Lo encontramos, salimos del bucle
        }
    }

    // 2. Si se encuentra, eliminar y reorganizar la memoria
    if (pos != -1) {
        // A. Liberamos la memoria de la cadena exacta (ej: "OB01")
        free(jugador->Inventario[pos]);

        // B. Desplazamos los PUNTEROS (no las letras) para cerrar el hueco
        for (int i = pos; i < jugador->Num_objetos - 1; i++) {
            jugador->Inventario[i] = jugador->Inventario[i + 1];
        }

        jugador->Num_objetos--;

        // C. Redimensionamos el array principal para que ocupe menos espacio
        if (jugador->Num_objetos > 0) {
            jugador->Inventario = realloc(jugador->Inventario, jugador->Num_objetos * sizeof(char*));
        } else {
            // Si el inventario se queda completamente vac�o, liberamos el puntero y lo ponemos a NULL
            free(jugador->Inventario);
            jugador->Inventario = NULL;
        }

        eliminado = 1;
    }

    return eliminado;
}

/*
 * Funcion    : tieneObjeto
 * Descripcion: Comprueba si el identificador de un objeto se encuentra
 *              en el inventario del jugador.
 * Retorno    : 1 si esta en el inventario; 0 si no.
 */
int tieneObjeto(Jugador *jugador, char idObj[]) {
    int i;
    int encontrado = 0;

    // F�jate en la may�scula de Num_objetos
    for (i = 0; i < jugador->Num_objetos && !encontrado; i++) {
        // F�jate en la may�scula de Inventario
        if (strcmp(jugador->Inventario[i], idObj) == 0) {
            encontrado = 1;
        }
    }
    return encontrado;
}

/* =========================================================
 * Presentacion y validacion
 * ========================================================= */

/*
 * Funcion    : mostrarJugador
 * Descripcion: Muestra por pantalla el identificador, nombre de usuario
 *              y sala actual del jugador, ademas de listar su inventario.
 */
void mostrarJugador(Jugador *jugador, char* nombreSalaActual) {
    int i;

    printf("\n+-----------------------------------------+\n");
    // Id_jugador ahora es int, usamos %02d para mantener el formato de 2 d�gitos
    printf("  JUGADOR [%02d] - %s\n", jugador->Id_jugador, jugador->Nomb_jugador);
    printf("  Usuario    : %s\n",   jugador->Jugador);

    // Como salaActual no est� en la estructura Jugador, la pasamos como par�metro
    printf("  Sala actual: %s\n",   nombreSalaActual != NULL ? nombreSalaActual : "(sin asignar)");

    printf("  Inventario : ");

    if (jugador->Num_objetos == 0) {
        printf("(vacio)\n");
    } else {
        printf("\n");
        for (i = 0; i < jugador->Num_objetos; i++) {
            // jugador->Inventario[i] accede al puntero char* de la lista din�mica
            printf("    [%d] %s\n", i + 1, jugador->Inventario[i]);
        }
    }
    printf("+-----------------------------------------+\n\n");
}

/*
 * Funcion    : validarJugador
 * Descripcion: Comprueba que los campos obligatorios no esten vacios:
 *              idJugador, nombJugador, usuario y contrasena.
 * Retorno    : 1 si el jugador es valido; 0 en caso contrario.
 */
int validarJugador(Jugador *jugador) {
    int valido = 1;

    // Buena pr�ctica de seguridad al usar punteros din�micos
    if (jugador == NULL) return 0;

    // Como Id_jugador ahora es un int, comprobamos que sea mayor que 0
    if (jugador->Id_jugador <= 0) {
        fprintf(stderr, "  [JUGADOR] Error: identificador invalido.\n");
        valido = 0;
    }

    // Usamos strlen() de la libreria <string.h> para comprobar cadenas vac�as
    if (strlen(jugador->Nomb_jugador) == 0) {
        fprintf(stderr, "  [JUGADOR %02d] Error: nombre vacio.\n", jugador->Id_jugador);
        valido = 0;
    }

    if (strlen(jugador->Jugador) == 0) {
        fprintf(stderr, "  [JUGADOR %02d] Error: usuario vacio.\n", jugador->Id_jugador);
        valido = 0;
    }

    if (strlen(jugador->Contrasenna) == 0) {
        fprintf(stderr, "  [JUGADOR %02d] Error: contrasena vacia.\n", jugador->Id_jugador);
        valido = 0;
    }

    return valido;
}
