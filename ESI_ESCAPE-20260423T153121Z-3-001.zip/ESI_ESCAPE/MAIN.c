#include <stdio.h>
#include <stdlib.h>
#include "Ficheros.h"
#include "Acciones.h"
#include "FlujoPartida.h"

int main() {
    // 1. DECLARACI�N DE VARIABLES Y PUNTEROS DIN�MICOS
    int total_salas = 0, total_objetos = 0, total_puzles = 0, total_conexiones = 0;
    int num_jugadores = 0, total_partidas = 0;
    char nuevo_user[11], nueva_pass[9], nuevo_nombre[21];

    // Carga de datos maestros (solo lectura)
    Sala** lista_salas = cargar_salas("Salas.txt", &total_salas);
    Objeto** lista_objetos = cargar_objetos("Objetos.txt", &total_objetos);
    Puzle** lista_puzles = cargar_puzles("Puzles.txt", &total_puzles);
    Conexion** lista_conexiones = cargar_conexiones("Conexiones.txt", &total_conexiones);

    // Carga de datos de usuario (lectura/escritura)
    Jugador** lista_jugadores = cargar_jugadores("Jugadores.txt", &num_jugadores);
    Partida** lista_partidas = cargar_partidas("Partida.txt", &total_partidas);

    int opcion_menu = 0, modo;
    Jugador* jugador_logeado = NULL;

    printf("BIENVENIDO A ESI-ESCAPE\n");

    // 2. MEN� PRINCIPAL
    do {
        printf("\n=== MENU PRINCIPAL ===\n");
        printf("1. Login\n");
        printf("2. Registrarse\n");
        printf("3. Salir\n");
        printf("Opcion: ");


        scanf("%i", &opcion_menu);

        switch(opcion_menu) {
            case 1: { // LOGIN
                char user[11], pass[9];
                printf("Usuario: "); scanf("%10s", user);
                printf("Contrasena: "); scanf("%8s", pass);
                while(getchar() != '\n'); // Limpiar buffer

                jugador_logeado = hacer_login(lista_jugadores, num_jugadores, user, pass);

                if (jugador_logeado != NULL) {
                    printf("Bienvenido, %s\n", jugador_logeado->Nomb_jugador);

                    // Preguntar si quiere cargar o nueva
                    printf("1. Nueva Partida\n2. Cargar Partida\nOpcion: ");
                    scanf("%i", &modo);


                    // 3. EJECUCI�N DEL FLUJO DE JUEGO
                    ejecutar_flujo_juego(jugador_logeado, lista_salas, total_salas, lista_objetos, total_objetos, lista_puzles, total_puzles, lista_conexiones, total_conexiones, lista_partidas, &total_partidas, (modo == 1));
                } else {
                    printf("Usuario o contrase�a incorrectos.\n");
                }
                break;
            }
            case 2:
                printf("\n--- REGISTRO DE NUEVO JUGADOR ---\n");
                printf("Introduce nombre de usuario (max 10): ");
                scanf("%10s", nuevo_user);
                while(getchar() != '\n'); // Limpiar buffer

                // 1. Comprobar si el usuario ya existe
                if (buscarJugador(lista_jugadores, num_jugadores, nuevo_user) != -1) {
                    printf("Error: El usuario '%s' ya est� registrado.\n", nuevo_user);
                } else {
                    printf("Introduce contrasena (max 8): ");
                    scanf("%8s", nueva_pass);
                    while(getchar() != '\n');

                    printf("Introduce tu nombre completo: ");
                    fgets(nuevo_nombre, sizeof(nuevo_nombre), stdin);
                    nuevo_nombre[strcspn(nuevo_nombre, "\n")] = '\0';

                    // 2. Crear la estructura del nuevo jugador
                    Jugador* nuevo = malloc(sizeof(Jugador));
                    // Calculamos el nuevo ID bas�ndonos en el mayor actual
                    nuevo->Id_jugador = id_mayor(lista_jugadores, num_jugadores) + 1;
                    strcpy(nuevo->Jugador, nuevo_user);
                    strcpy(nuevo->Contrasenna, nueva_pass);
                    strcpy(nuevo->Nomb_jugador, nuevo_nombre);
                    nuevo->Inventario = NULL;
                    nuevo->Num_objetos = 0;

                    // 3. Validar y a�adir a la lista din�mica
                    if (validarJugador(nuevo)) {
                        lista_jugadores = registrarJugador(lista_jugadores, &num_jugadores, nuevo);

                        // 4. Guardar inmediatamente en el fichero para persistencia
                        guardar_jugadores("Jugadores.txt", lista_jugadores, num_jugadores);
                        printf("�Registro completado con �xito! Ya puedes hacer login.\n");
                    } else {
                        printf("Error: Los datos introducidos no son v�lidos.\n");
                        free(nuevo);
                    }
                }
                break;
        }
    } while (opcion_menu != 3);

    // 4. LIBERACI�N DE MEMORIA (Importante por el uso de realloc/malloc)
    destruir_lista_salas(lista_salas, total_salas);
    destruir_lista_objetos(lista_objetos, total_objetos);
    destruir_lista_puzles(lista_puzles, total_puzles);
    // ... etc

    return 0;
}
