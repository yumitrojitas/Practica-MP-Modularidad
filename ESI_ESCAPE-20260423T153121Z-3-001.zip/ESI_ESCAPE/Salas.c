#include <stdio.h>
#include <string.h>
#include "Salas.h"


// Funcion    : buscarSala
// Descripcion: Busca una sala por su identificador en la lista.
int buscarSala(Sala** lista, int num, int idBuscado) {
    for (int i = 0; i < num; i++) {
        if (lista[i]->id_sala == idBuscado) {
            return i;
        }
    }
    return -1;
}


// Funcion    : buscarSalaInicial
// Descripcion: Comprueba si una sala concreta es de tipo INICIAL.
int buscarIdSalaInicial(Sala** lista_salas, int total_salas) {
    if (lista_salas == NULL) return -1;

    for (int i = 0; i < total_salas; i++) {
        // Comparamos el campo 'tipo' usando la estructura de Ficheros.h
        if (strcmp(lista_salas[i]->tipo, "INICIAL") == 0) {
            return lista_salas[i]->id_sala;
        }
    }

    return -1; // No se encontr� ninguna sala marcada como INICIAL
}


// Funcion    : esSalaSalida
// Descripcion: Comprueba si una sala es de tipo SALIDA.
int esSalaSalida(Sala *sala) { // Cambiamos tSala por Sala
    if (sala != NULL && strcmp(sala->tipo, TIPO_SALIDA) == 0) {
        return 1;
    } else {
        return 0;
    }
}


// Funcion    : mostrarDescripcionSala
// Descripcion: Muestra por pantalla el nombre, tipo y descripcion de la sala.
//              Si es de tipo SALIDA, muestra ademas un aviso de victoria.
void mostrarDescripcionSala(Sala* s) {
    printf("Sala: %s\n", s->nomb_sala);
    printf("Descripcion: %s\n", s->descrip);
    if (strcmp(s->tipo, "SALIDA") == 0) {
        printf("\n*** �Has llegado a la salida! ***\n");
    }
}


// Funcion    : validarSala
// Descripcion: Comprueba que los campos obligatorios no esten vacios y que
//             el tipo sea exactamente INICIAL, NORMAL o SALIDA.
int validarSala(Sala *sala) {
    int valida = 1;

    // 1. Buena pr�ctica: comprobar que el puntero no sea nulo
    if (sala == NULL) {
        return 0;
    }

    // 2. id_sala ahora es un int, no un char array.
    // Comprobamos que sea un ID v�lido (por ejemplo, mayor que 0)
    if (sala->id_sala <= 0) {
        printf("Error: sala con identificador inv�lido (menor o igual a 0).\n");
        valida = 0;
    }

    // 3. nombSala pasa a ser nomb_sala
    if (sala->nomb_sala[0] == '\0') {
        // Usamos %02d para imprimir el int con 2 d�gitos, como pide el guion
        printf("Error: sala %02d sin nombre.\n", sala->id_sala);
        valida = 0;
    }

    // 4. Se mantienen los tipos, pero usamos literales directos por si acaso
    // no tienes los #define accesibles en este punto
    if (strcmp(sala->tipo, "INICIAL") != 0 &&
        strcmp(sala->tipo, "NORMAL" ) != 0 &&
        strcmp(sala->tipo, "SALIDA" ) != 0) {
        printf("Error: sala %02d con tipo desconocido: %s\n",
               sala->id_sala, sala->tipo);
        valida = 0;
    }

    return valida;
}
