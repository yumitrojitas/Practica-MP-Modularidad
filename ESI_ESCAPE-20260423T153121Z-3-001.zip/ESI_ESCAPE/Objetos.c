//Este m�dulo contiene la l�gica para gestionar los objetos del juego, su localizaci�n en salas o en el inventario, y su visualizaci�n

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Objetos.h"

//Funci�n: buscarObjeto
//Descripci�n: Busca un objeto por su identificador en la lista global.
//Retorna el indice del array si se encuentra, -1 si no.
int buscarObjeto(Objeto** lista_objetos, int total_objetos, char* idObj) {
    for (int i = 0; i < total_objetos; i++) {
        // Usamos -> porque lista_objetos[i] ahora es un puntero a un Objeto
        if (strcmp(lista_objetos[i]->id_obj, idObj) == 0) {
            return i; // Lo hemos encontrado, devolvemos su posici�n
        }
    }
    return -1; // Termina el bucle y no se encontr�
}

//Funcion: buscarObjetoEnSala
//Descripci�n: Busca el primer objeto ubicado en una sala espec�fica
//Retorna el indice del array si se encuentra, -1 si no.
int buscarObjetoEnSala(Objeto** lista_objetos, int total_objetos, char* idSala) {
    for (int i = 0; i < total_objetos; i++) {
        // Usamos -> porque lista_objetos[i] ahora es un puntero a Objeto
        if (strcmp(lista_objetos[i]->localiz, idSala) == 0) {
            return i;
        }
    }
    return -1;
}

//Funci�n: estaEnInventario
//Descripci�n: Comprueba si un objeto pertenece al inventario del jugador.
//Retorna 1 si esta en el inventario, 0 si no.
int estaEnInventario(Objeto *obj) {
    // Comprobamos que el puntero no sea nulo y que su campo localiz sea "Inventario"
    if (obj != NULL && strcmp(obj->localiz, "Inventario") == 0) {
        return 1;
    }
    return 0;
}

//Funci�n: moverObjetoASala
//Descripci�n: Cambia la ubicaci�n de un objeto a una sala determinada.
void moverObjetoASala(Objeto *obj, char* idSala) {
    if (obj != NULL && idSala != NULL) {
        // Usamos sizeof para detectar autom�ticamente los 15 caracteres del Ficheros.h
        strncpy(obj->localiz, idSala, sizeof(obj->localiz) - 1);
        obj->localiz[sizeof(obj->localiz) - 1] = '\0'; // Asegura el fin de cadena
    }
}

//Funci�n: moverObjetoAInventario
//Descripci�n: Cambia la ubicaci�n de un objeto al inventario del jugador.
void moverObjetoAInventario(Objeto *obj) {
    if (obj != NULL) {
        // Usamos el nombre de la estructura 'Objeto' de Ficheros.h
        // El tama�o de localiz es 15, "Inventario" cabe perfectamente.
        strcpy(obj->localiz, "Inventario");
    }
}

//Funci�n: mostrarObjeto
//Descripci�n: Muestra la informaci�n descriptiva de un objeto por consola.
void mostrarObjeto(Objeto *obj) {
    if (obj != NULL) {
        // Usamos los nombres exactos definidos en tu Ficheros.h
        printf("%s: %s\n", obj->nomb_obj, obj->descrip);
    }
}

//Funci�n: listarObjetosEnSala
//Descripci�n: Lista todos los objetos presentes en una sala.
void listarObjetosEnSala(Objeto** lista, int num, int idSala) {
    int encontrado = 0;
    char sala_str[15];

    // Convertimos el n�mero entero (ej: 3) a una cadena de 2 d�gitos (ej: "03")
    // Esto es necesario porque en el fichero de objetos se guardan como texto
    sprintf(sala_str, "%02d", idSala);

    for (int i = 0; i < num; i++) {
        // Comparamos si la localizaci�n del objeto coincide con la sala convertida
        if (strcmp(lista[i]->localiz, sala_str) == 0) {
            printf("%s - %s: %s\n", lista[i]->id_obj, lista[i]->nomb_obj, lista[i]->descrip);
            encontrado = 1;
        }
    }

    if (!encontrado) {
        printf("- No hay objetos a simple vista en esta sala.\n");
    }
}

//Funci�n: listarInventario
//Descripci�n: Muestra el contenido del inventario del jugador.
void listarInventario(Objeto** lista, int num) {
    int encontrado = 0;

    printf("\n--- TU INVENTARIO ---\n");
    for (int i = 0; i < num; i++) {
        if (strcmp(lista[i]->localiz, "Inventario") == 0) {
            printf("- %s: %s\n", lista[i]->nomb_obj, lista[i]->descrip);
            encontrado = 1;
        }
    }

    if (!encontrado) {
        printf("Tus bolsillos est�n vac�os.\n");
    }
}

//Funci�n: validarObjeto
//Descripci�n: Comprueba si los campos de un objeto no esten vac�os y que la localizaci�n sea v�lida.
//Retorna 1 si es v�lido, 0 si no.
int validarObjeto(Objeto *obj) {
    // 1. Si el puntero es nulo, el objeto no es v�lido
    if (obj == NULL) return 0;

    // 2. Comprobar que el ID, el nombre y la descripci�n no est�n vac�os
    if (strlen(obj->id_obj) == 0 || strlen(obj->nomb_obj) == 0 || strlen(obj->descrip) == 0) {
        return 0;
    }

    // 3. Comprobar que la localizaci�n (Sala o Inventario) no est� vac�a
    if (strlen(obj->localiz) == 0) {
        return 0;
    }

    // Si pasa todas las pruebas, el objeto es v�lido
    return 1;
}
