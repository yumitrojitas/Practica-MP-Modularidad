//Descripcion: Implementacion del modulo de gestion de puzles del juego.
//Proporciona operaciones para inicializar, buscar, mostrar
//y comprobar la solucion de los puzles del Escape Room.

#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include "Puzles.h"

//Funciones auxuliares


// Funcion auxiliar: strToLower
// Descripcion: Convierte una cadena a minusculas en un buffer destino. No modifica la cadena original.
static void strToLower(char dest[], const char origen[], int tam) {
    int i;
    for (i = 0; i < tam - 1 && origen[i] != '\0'; i++) {
        dest[i] = (char) tolower((unsigned char) origen[i]);
    }
    dest[i] = '\0';
}

//Implementacion de funciones



//Funcion    : buscarPuzle
//Descripcion: Busca un puzle por su identificador en la lista. Retorna el indice del puzle si se encuentra, -1 si no.
//La busqueda distingue mayusculas de minusculas tal como estan almacenados los identificadores en el fichero.
int buscarPuzle(Puzle** lista_puzles, int total_puzles, char* idPuzle) {
    // Recorremos el array din�mico
    for (int i = 0; i < total_puzles; i++) {
        // Comparamos el ID buscado con el id_puzle de la estructura actual
        if (strcmp(lista_puzles[i]->id_puzle, idPuzle) == 0) {
            return i; // Si coincide, devolvemos en qu� posici�n del array est�
        }
    }

    return -1; // Si termina el bucle y no lo ha encontrado, devolvemos -1
}

/*
 * Funcion    : buscarPuzleEnSala
 * Descripcion: Devuelve el indice del PRIMER puzle asociado a la sala
 *              indicada que se encuentre PENDIENTE de resolver.
 *              Util para verificar si una sala tiene un puzle activo
 *              antes de permitir el acceso a una conexion bloqueada.
 * Retorno    : Indice del puzle si se encuentra; -1 si no existe ninguno
 *              pendiente para esa sala.
 */
int buscarPuzleEnSala(Puzle** lista, int num, int idSala) {
    for (int i = 0; i < num; i++) {
        // Solo comprobamos que el puzle pertenezca a la sala
        if (lista[i]->id_sala == idSala) {
            return i;
        }
    }
    return -1;
}


//Funcion    : mostrarPuzle
//Descripcion: Muestra por pantalla el n�mero y enunciado del puzle, y si est� resuelto o no.
void mostrarPuzle(Puzle *puzle) {
    if (puzle == NULL) return;

    printf("\n+-----------------------------------------+\n");
    // Cambiado idPuzle por id_puzle (seg�n tu Ficheros.h)
    printf("  Puzle Numero %s \n", puzle->id_puzle);
    printf("+-----------------------------------------+\n");
    printf("  %s\n", puzle->descrip);
}


//Funcion    : comprobarSolucion
//Descripcion: Compara la respuesta del jugador con la solucion almacenada en el puzle sin distinguir mayusculas de minusculas.
//Si la respuesta es correcta, marca el puzle como resuelto y retorna 1.
int comprobarSolucion(Puzle *puzle, char respuesta[]) {
    // Usamos 51 porque en Ficheros.h la soluci�n tiene un tama�o m�ximo de 50 + '\0'
    char respLower[51];
    char solLower [51];
    int  correcto;

    strToLower(respLower, respuesta,  51);
    strToLower(solLower,  puzle->sol, 51); // Accedemos al campo 'sol' de Ficheros.h

    correcto = (strcmp(respLower, solLower) == 0);

    return correcto;
}

//Funcion: validarPuzle
//Descripcion: comprueba que ningun apartado del registro est� vac�o. Retorna 1 si es v�lido y 0 en caso contrario.
int validarPuzle(Puzle *puzle) {
    int valido = 1;

    // Buena pr�ctica: comprobar que el puntero no sea nulo antes de leerlo
    if (puzle == NULL) {
        return 0;
    }

    if (puzle->id_puzle[0] == '\0') {
        fprintf(stderr, "  [PUZLE] Error: identificador vacio.\n");
        valido = 0;
    }

    if (puzle->nomb_puz[0] == '\0') {
        fprintf(stderr, "  [PUZLE %s] Error: nombre vacio.\n", puzle->id_puzle);
        valido = 0;
    }

    // ATENCI�N: id_sala ahora es un INT, comprobamos que sea mayor que 0
    if (puzle->id_sala <= 0) {
        fprintf(stderr, "  [PUZLE %s] Error: id de sala no valido (%d).\n", puzle->id_puzle, puzle->id_sala);
        valido = 0;
    }

    // Aceptamos "Codigo" sin tilde y "C�digo" con tilde para evitar cuelgues con el formato del txt
    if (strcmp(puzle->tipo, "Codigo") != 0 &&
        strcmp(puzle->tipo, "C�digo") != 0 &&
        strcmp(puzle->tipo, "Palabra") != 0) {
        fprintf(stderr, "  [PUZLE %s] Error: tipo '%s' no valido "
                        "(debe ser 'Codigo', 'C�digo' o 'Palabra').\n",
                puzle->id_puzle, puzle->tipo);
        valido = 0;
    }

    if (puzle->descrip[0] == '\0') {
        fprintf(stderr, "  [PUZLE %s] Error: descripcion vacia.\n", puzle->id_puzle);
        valido = 0;
    }

    if (puzle->sol[0] == '\0') {
        fprintf(stderr, "  [PUZLE %s] Error: solucion vacia.\n", puzle->id_puzle);
        valido = 0;
    }

    return valido;
}
