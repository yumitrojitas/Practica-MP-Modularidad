#ifndef ESTRUCTURAS_H
#define ESTRUCTURAS_H

//ESTRUCTURA
typedef struct {    //ESTRUCTURA JUGADOR

    int Id_jugador, Num_objetos;
    char Nomb_jugador[21], Jugador[11], Contrasenna[9];
    char** Inventario;
}Jugador;

typedef struct {    //ESTRUCTURA PUZLE
    char id_puzle[4];    // 3 caracteres + '\0'
    char nomb_puz[16];   // 15 caracteres m�ximo + '\0'
    int id_sala;         // 2 d�gitos
    char tipo[15];       // "C�digo" o "Palabra" + '\0' (damos margen por la tilde)
    char descrip[151];   // 150 caracteres m�ximo + '\0'
    char sol[51];        // 50 caracteres m�ximo + '\0'
    int estado_actual;
} Puzle;

typedef struct {    //ESTRUCTURA OBJETO
    char id_obj[5];      // 4 caracteres + '\0'
    char nomb_obj[16];   // 15 caracteres m�ximo + '\0'
    char descrip[51];    // 50 caracteres m�ximo + '\0'
    char localiz[15];    // Id_sala o "Inventario" + '\0'
} Objeto;

typedef struct {    //ESTRUCUTRA SALA
    int id_sala;
    char nomb_sala[31];
    char tipo[10];
    char descrip[151];
} Sala;

typedef struct {    //ESTRUCTURA CONEXION
    char id_conexion[4];     // 3 caracteres m�ximo + '\0'
    int id_origen;           // 2 d�gitos
    char nomb_origen[31];    // Nombre de la sala origen (seg�n el ejemplo del guion)
    int id_destino;          // 2 d�gitos
    char nomb_destino[31];   // Nombre de la sala destino (seg�n el ejemplo del guion)
    char estado[11];         // "Activa" o "Bloqueada" + '\0'
    char cond[5];            // 0, Id_obj (4 chars) o Id_puzle (3 chars) + '\0'
} Conexion;

typedef struct {    //ESTRUCTURA ESTADO OBJETO

    char id_obj[5];
    char localizacion[15]; // Puede ser una sala ("03") o "Inventario"
} EstadoObjeto;

typedef struct {    //ESTRUCTURA ESTADO CONEXION
    char id_conexion[4];
    char estado[11]; // "Activa" o "Bloqueada"
} EstadoConexion;

typedef struct {    //ESTRUCTURA ESTADO PUZLE
    char id_puzle[4];
    char estado[11]; // "Resuelto" o "Pendiente"
} EstadoPuzle;

typedef struct {    //ESTRUCTURA PARTIDA
    int id_jugador;
    int id_sala_actual;

    // Arrays din�micos para las listas variables
    EstadoObjeto* objetos_modificados;
    int num_objetos;

    EstadoConexion* conexiones_modificadas;
    int num_conexiones;

    EstadoPuzle* puzles_modificados;
    int num_puzles;
} Partida;
#endif // ESTRUCTURAS_H
