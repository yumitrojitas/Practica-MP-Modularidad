#ifndef SALAS_H
#define SALAS_H

#include "Estructuras.h"

/*-- Constantes ---------------------------------------------------------------*/

#define TAM_ID_SALA        2
#define TAM_NOMB_SALA     30
#define TAM_TIPO_SALA     7    //El maximo de caracteres lo tiene "INICIAL" con 7
#define TAM_DESCRIP_SALA 150

// Valores posibles del campo tipo de sala, segun Salas.txt */
#define TIPO_INICIAL  "INICIAL"
#define TIPO_NORMAL   "NORMAL"
#define TIPO_SALIDA   "SALIDA"



//Funciones

/* Recorre la lista buscando la sala cuyo idSala coincide con el parametro.   */
/* Devuelve el indice si la encuentra, o -1 si no existe ninguna sala con      */
/* ese identificador.                                                          */
int buscarSala(Sala** lista, int num, int idBuscado);



/* Recorre la lista y devuelve 1 si se est� en la sala INICIAL y 0 si no.  */
int buscarIdSalaInicial(Sala** lista_salas, int total_salas);


/* Devuelve 1 si la sala es de tipo SALIDA, 0 en caso contrario.              */
int esSalaSalida(Sala *sala);



/* Imprime el nombre, tipo y descripcion de la sala con el formato del juego. */
/* Si la sala es de tipo SALIDA, anade un aviso de victoria al jugador.       */
void mostrarDescripcionSala(Sala* s);




/* Comprueba que idSala y nombSala no esten vacios y que el campo tipo sea     */
/* exactamente "INICIAL", "NORMAL" o "SALIDA". Devuelve 1 si todo es          */
/* correcto, 0 si se detecta alguna anomalia.                                  */
int validarSala(Sala *sala);

#endif /* SALAS_H */
