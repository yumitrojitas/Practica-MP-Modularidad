#ifndef JUGADOR_H
#define JUGADOR_H

#include "Estructuras.h"

//Constantes
#define TAM_ID_JUGADOR      2
#define TAM_NOMB_JUGADOR   20
#define TAM_USUARIO        10
#define TAM_CONTRASENA      8
#define TAM_ID_OBJ_INV      4
#define TAM_ID_SALA         2



//Declaracion funciones


// Recorre la lista buscando el jugador cuyo campo usuario coincide con el
// parametro. Devuelve el indice si lo encuentra, -1 en caso contrario.
int buscarJugador(Jugador** lista, int num, char* usuario);

// A�ade un nuevo jugador al final de la lista incrementando numJugadores.
// Devuelve 1 si se pudo registrar, 0 si la lista esta llena.
Jugador** registrarJugador(Jugador** lista, int* num_jugadores, Jugador* nuevo_jugador);



// Actualiza el campo salaActual del jugador con el identificador indicado.
void actualizarPosicionJugador(Partida *p_actual, int nueva_sala);


// Agrega el identificador de un objeto al inventario del jugador.
// Devuelve 1 si se pudo anadir, 0 si el inventario esta lleno.
int agregarObjetoInventario(Jugador* j, char* idObj);

// Elimina el identificador de un objeto del inventario del jugador
// desplazando los elementos posteriores para no dejar huecos.
// Devuelve 1 si se encontr� y elimino, 0 si el objeto no estaba.
int eliminarObjetoInventario(Jugador *jugador, char* idObj);

// Comprueba si el identificador de un objeto se encuentra en el inventario.  */
// Devuelve 1 si esta, 0 si no.                                               */
int tieneObjeto(Jugador *jugador, char idObj[]);


// Muestra por pantalla el identificador, nombre de usuario y sala actual del jugador.
void mostrarJugador(Jugador *jugador, char* nombreSalaActual);

// Comprueba que los campos obligatorios no esten vacios. Devuelve 1 si el
// jugador es valido, 0 en caso contrario.
int validarJugador(Jugador *jugador);

#endif /* JUGADOR_H */
