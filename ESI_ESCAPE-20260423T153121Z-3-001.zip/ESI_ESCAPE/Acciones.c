#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "Acciones.h"

/*
  Funci�n:      hacer_login
  Descripcion:  Comprueba las credenciales de un usuario buscando
                coincidencias de nombre de usuario y contrase�a en el sistema.
  Devuelve:     Puntero al jugador si es correcto.
*/
Jugador* hacer_login(Jugador** lista_jugadores, int num_jugadores, char* user, char* pass) {
    if (lista_jugadores == NULL) return NULL;

    for (int i = 0; i < num_jugadores; i++) {
        if (strcmp(lista_jugadores[i]->Jugador, user) == 0 && strcmp(lista_jugadores[i]->Contrasenna, pass) == 0) {
            return lista_jugadores[i];
        }
    }

    return NULL;
}

/*
  Funci�n:      id_mayor
  Descripcion:  Recorre la lista de jugadores para encontrar y devolver
                el identificador num�rico (ID) m�s alto registrado.
  Devuelve:     Entero con el ID m�s alto.
*/
int id_mayor(Jugador** lista_jugadores, int num_jugadores) {
    if (lista_jugadores == NULL) return 0;

    int max = 0;

    for (int i = 0; i < num_jugadores; i++)
    {
        if(lista_jugadores[i]->Id_jugador > max)
            max = lista_jugadores[i]->Id_jugador;
    }

    return max;
}

/*
  Funci�n:      guardar_partida
  Descripcion:  Guarda o actualiza el estado actual de la partida de un jugador,
                almacenando la sala actual y el estado de los objetos, conexiones
                y puzles de la sesi�n.
  Devuelve:     Array din�mico de partidas actualizado.
*/
Partida** guardar_partida(Jugador* jugador_actual, int id_sala_actual, Partida** lista_partidas, int* total_partidas, Objeto** lista_objetos_activos, int total_obj, Conexion** lista_conexiones_activas, int total_con) {
    Partida* p_actual = NULL;

    // 1. Buscar si el jugador ya tiene una partida registrada
    for (int i = 0; i < *total_partidas; i++) {
        if (lista_partidas[i]->id_jugador == jugador_actual->Id_jugador) {
            p_actual = lista_partidas[i];
            break;
        }
    }

    // 2. Si es una partida nueva para este jugador, reservar memoria
    if (p_actual == NULL) {
        lista_partidas = realloc(lista_partidas, (*total_partidas + 1) * sizeof(Partida*));
        p_actual = malloc(sizeof(Partida));

        p_actual->id_jugador = jugador_actual->Id_jugador;
        p_actual->puzles_modificados = NULL; // Se inicializa a NULL por seguridad
        p_actual->num_puzles = 0;

        lista_partidas[*total_partidas] = p_actual;
        (*total_partidas)++;
    } else {
        // Liberar solo lo que vamos a sobreescribir
        if (p_actual->objetos_modificados != NULL) free(p_actual->objetos_modificados);
        if (p_actual->conexiones_modificadas != NULL) free(p_actual->conexiones_modificadas);
    }

    // 3. Actualizar datos generales de la partida
    p_actual->id_sala_actual = id_sala_actual;

    // 4. Guardar estado de OBJETOS
    p_actual->objetos_modificados = NULL;
    p_actual->num_objetos = 0;

    for (int i = 0; i < total_obj; i++) {
        p_actual->objetos_modificados = realloc(p_actual->objetos_modificados,
                                                (p_actual->num_objetos + 1) * sizeof(EstadoObjeto));

        strcpy(p_actual->objetos_modificados[p_actual->num_objetos].id_obj, lista_objetos_activos[i]->id_obj);
        strcpy(p_actual->objetos_modificados[p_actual->num_objetos].localizacion, lista_objetos_activos[i]->localiz);

        p_actual->num_objetos++;
    }

    // 5. Guardar estado de CONEXIONES (solo las Activas)
    p_actual->conexiones_modificadas = NULL;
    p_actual->num_conexiones = 0;

    for (int i = 0; i < total_con; i++) {
        if (strcmp(lista_conexiones_activas[i]->estado, "Activa") == 0) {
            p_actual->conexiones_modificadas = realloc(p_actual->conexiones_modificadas,
                                                       (p_actual->num_conexiones + 1) * sizeof(EstadoConexion));

            strcpy(p_actual->conexiones_modificadas[p_actual->num_conexiones].id_conexion, lista_conexiones_activas[i]->id_conexion);
            strcpy(p_actual->conexiones_modificadas[p_actual->num_conexiones].estado, lista_conexiones_activas[i]->estado);

            p_actual->num_conexiones++;
        }
    }

    return lista_partidas;
}
