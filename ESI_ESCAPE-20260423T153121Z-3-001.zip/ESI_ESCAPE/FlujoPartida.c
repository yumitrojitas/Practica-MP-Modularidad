#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "FlujoPartida.h"

void ejecutar_flujo_juego(Jugador* jugador_actual, Sala** lista_salas, int total_salas, Objeto** lista_objetos, int total_objetos, Puzle** lista_puzles, int total_puzles, Conexion** lista_conexiones, int total_conexiones, Partida** lista_partidas, int* total_partidas, int es_nueva_partida) {

    int opcion = 0;
    int id_sala_actual;

    // Variables para la l�gica de conexiones (Opci�n 3)
    int hay_conexiones;
    int opciones_conexiones[10];
    int contador_con;

    // 1. CONFIGURACI�N INICIAL DEL ESTADO
    if (!es_nueva_partida) {
        Partida* p_actual = NULL;

        // 1. Buscar la partida del jugador logeado
        for (int i = 0; i < total_partidas; i++) {
            if (lista_partidas[i]->id_jugador == jugador_actual->Id_jugador) {
                p_actual = lista_partidas[i];
            }
        }

        // 2. Si existe la partida, sincronizamos el mundo en vivo
        if (p_actual != NULL) {
            // --- SINCRONIZAR OBJETOS ---
            for (int i = 0; i < p_actual->num_objetos; i++) {
                int idx_obj = buscarObjeto(lista_objetos, total_objetos, p_actual->objetos_modificados[i].id_obj);
                if (idx_obj != -1) {
                    // Actualizamos la localizaci�n del objeto maestro con la guardada
                    strcpy(lista_objetos[idx_obj]->localiz, p_actual->objetos_modificados[i].localizacion);

                    // Si el objeto estaba en el inventario, hay que meterlo en la mochila del jugador
                    if (strcmp(p_actual->objetos_modificados[i].localizacion, "Inventario") == 0) {
                        agregarObjetoInventario(jugador_actual, p_actual->objetos_modificados[i].id_obj);
                    }
                }
            }

            // --- SINCRONIZAR CONEXIONES ---
            for (int i = 0; i < p_actual->num_conexiones; i++) {
                for (int j = 0; j < total_conexiones; j++) {
                    if (strcmp(lista_conexiones[j]->id_conexion, p_actual->conexiones_modificadas[i].id_conexion) == 0) {
                        strcpy(lista_conexiones[j]->estado, p_actual->conexiones_modificadas[i].estado);
                    }
                }
            }
        }
    }

    // 2. BUCLE PRINCIPAL DE LA PARTIDA
    while (opcion != 10) {
        // REINICIO DE VARIABLES DE CONTROL EN CADA VUELTA
        hay_conexiones = 0;
        contador_con = 0;

        int idx_sala = buscarSala(lista_salas, total_salas, id_sala_actual);

        // Si por error el ID de sala no existe, evitamos un crash
        if (idx_sala == -1) {
            printf("Error cr�tico: Sala %d no encontrada.\n", id_sala_actual);
            opcion = 10;
            continue;
        }

        printf("\n-----------------------------------------------\n");
        printf("SALA: %s\n", lista_salas[idx_sala]->nomb_sala);
        printf("-----------------------------------------------\n");
        printf("1. Describir sala\n2. Examinar (objetos y salidas)\n3. Entrar en otra sala\n");
        printf("4. Coger objeto\n5. Soltar objeto\n6. Inventario\n");
        printf("7. Usar objeto\n8. Resolver puzle\n9. Guardar partida\n10. Volver al men� principal\n");
        printf("Elige una accion: ");

        if (scanf("%i", &opcion) != 1) {
            opcion = 0; // Evitar bucle infinito si meten una letra
        }
        while(getchar() != '\n'); // LIMPIEZA TOTAL DEL BUFFER

        switch (opcion) {
            case 1:
                mostrarDescripcionSala(lista_salas[idx_sala]);
                break;

            case 2:
                listarObjetosEnSala(lista_objetos, total_objetos, id_sala_actual);
                break;

            case 3: // ENTRAR EN OTRA SALA
                printf("\n--- SALIDAS DISPONIBLES ---\n");
                for (int i = 0; i < total_conexiones; i++) {
                    if (lista_conexiones[i]->id_origen == id_sala_actual) {
                        printf("%d. Ir a: %s [%s]\n", contador_con + 1,
                               lista_conexiones[i]->nomb_destino, lista_conexiones[i]->estado);
                        opciones_conexiones[contador_con] = i;
                        contador_con++;
                        hay_conexiones = 1;
                    }
                }

                if (!hay_conexiones) {
                    printf("No hay salidas visibles.\n");
                } else {
                    int sel;
                    printf("Selecci�n (0 para cancelar): ");
                    if(scanf("%d", &sel) == 1 && sel > 0 && sel <= contador_con) {
                        Conexion* c = lista_conexiones[opciones_conexiones[sel-1]];
                        if (strcmp(c->estado, "Activa") == 0) {
                            id_sala_actual = c->id_destino;
                            printf("Caminas hacia %s...\n", c->nomb_destino);
                        } else {
                            printf("Puerta cerrada. Requisito: %s\n", c->cond);
                        }
                    }
                    while(getchar() != '\n');
                }
                break;

            case 4: // COGER OBJETO
                {
                    char id_c[10];
                    printf("ID del objeto: ");
                    if (fgets(id_c, sizeof(id_c), stdin)) {
                        id_c[strcspn(id_c, "\n")] = '\0';
                        int i_obj = buscarObjeto(lista_objetos, total_objetos, id_c);

                        char s_actual[5];
                        sprintf(s_actual, "%02d", id_sala_actual);

                        if (i_obj != -1 && strcmp(lista_objetos[i_obj]->localiz, s_actual) == 0) {
                            moverObjetoAInventario(lista_objetos[i_obj]);
                            agregarObjetoInventario(jugador_actual, id_c);
                            printf("Recogido: %s\n", lista_objetos[i_obj]->nomb_obj);
                        } else {
                            printf("No se encuentra ese objeto aqu�.\n");
                        }
                    }
                }
                break;

            case 5: // SOLTAR OBJETO
                {
                    char id_s[10];
                    printf("ID a soltar: ");
                    if (fgets(id_s, sizeof(id_s), stdin)) {
                        id_s[strcspn(id_s, "\n")] = '\0';
                        if (tieneObjeto(jugador_actual, id_s)) {
                            int i_obj = buscarObjeto(lista_objetos, total_objetos, id_s);
                            char s_actual[5];
                            sprintf(s_actual, "%02d", id_sala_actual);
                            moverObjetoASala(lista_objetos[i_obj], s_actual);
                            eliminarObjetoInventario(jugador_actual, id_s);
                            printf("Objeto soltado.\n");
                        }
                    }
                }
                break;

            case 6:
                mostrarJugador(jugador_actual, lista_salas[idx_sala]->nomb_sala);
                break;

            case 7: // USAR OBJETO
                {
                    char id_u[10];
                    printf("ID objeto a usar: ");
                    if (fgets(id_u, sizeof(id_u), stdin)) {
                        id_u[strcspn(id_u, "\n")] = '\0';
                        if (tieneObjeto(jugador_actual, id_u)) {
                            for (int i = 0; i < total_conexiones; i++) {
                                if (lista_conexiones[i]->id_origen == id_sala_actual && strcmp(lista_conexiones[i]->cond, id_u) == 0) {
                                    strcpy(lista_conexiones[i]->estado, "Activa");
                                    printf("�Puerta abierta!\n");
                                }
                            }
                        }
                    }
                }
                break;

            case 8: // PUZLE
                {
                    int i_p = buscarPuzleEnSala(lista_puzles, total_puzles, id_sala_actual);
                    if (i_p != -1) {
                        mostrarPuzle(lista_puzles[i_p]);
                        char res[51];
                        printf("Respuesta: ");
                        if (fgets(res, sizeof(res), stdin)) {
                            res[strcspn(res, "\n")] = '\0';
                            if (comprobarSolucion(lista_puzles[i_p], res)) {
                                printf("�Correcto!\n");
                                // Desbloqueo de conexiones
                                for (int i = 0; i < total_conexiones; i++) {
                                    if (lista_conexiones[i]->id_origen == id_sala_actual && strcmp(lista_conexiones[i]->cond, lista_puzles[i_p]->id_puzle) == 0) {
                                        strcpy(lista_conexiones[i]->estado, "Activa");
                                    }
                                }
                            }
                        }
                    } else printf("No hay puzles aqu�.\n");
                }
                break;

            case 9:
                lista_partidas = guardar_partida(jugador_actual, id_sala_actual, lista_partidas, total_partidas, lista_objetos, total_objetos, lista_conexiones, total_conexiones);
                guardar_partidas("Partida.txt", lista_partidas, *total_partidas);
                printf("�Progreso guardado correctamente en Partida.txt!\n");
                break;
        }

        if (esSalaSalida(lista_salas[idx_sala])) {
            printf("\n�VICTORIA! Has escapado.\n");
            opcion = 10;
        }
    }
}
