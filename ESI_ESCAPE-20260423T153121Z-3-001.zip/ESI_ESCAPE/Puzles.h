#ifndef PUZLES_H
#define PUZLES_H

#include "Estructuras.h"

//Constantes

#define TAM_ID_PUZLE         3    //M�ximo tama�o del identificador
#define TAM_NOMB_PUZ        16    //M�ximo del nombre de puzle
#define TAM_ID_SALA          2    //Las salas solo pueden tener 2 digitos de identificador
#define TAM_TIPO_PUZ        10    //El tipo de puzle solo puede ser "Codigo" o "Palabra"
#define TAM_DESCRIP_PUZ    150    //La descripci�n de los puzles
#define TAM_SOL_PUZ         50    //El tama�o de la soluci�n de los puzles

//Valores 1 y 0 para Puzles resueltos y pendientes para funciones booleanas
#define PUZLE_RESUELTO       1
#define PUZLE_PENDIENTE      0



/*
  Funcion    : buscarPuzle
  Descripcion: Busca un puzle por su identificador en la lista.
               Retorna el indice del puzle si se encuentra, si no, -1
  Parametros : lista   - lista de puzles (entrada).
               idPuzle - identificador del puzle buscado (entrada).
 */
int buscarPuzle(Puzle** lista_puzles, int total_puzles, char* idPuzle);

/*
  Funcion    : buscarPuzleEnSala
  Descripcion: Devuelve el indice del primer puzle asociado a una sala concreta.
               Util para saber si una sala tiene puzle pendiente de resolver.
               Retorna el indice del puzle si se encuentra, si no, -1
  Parametros : lista  - lista de puzles (entrada).
               idSala - identificador de la sala (entrada).
 */
int buscarPuzleEnSala(Puzle** lista, int num, int idSala);


/*
  Funcion    : mostrarPuzle
  Descripcion: Muestra por pantalla el identificador, nombre, tipo y enunciado
               del puzle. Si ya esta resuelto, indica su estado. No retorna nada.
  Parametros : puzle - puntero al puzle a mostrar (entrada).
 */
void mostrarPuzle(Puzle *puzle);

/*
  Funcion    : comprobarSolucion
  Descripcion: Compara la respuesta introducida por el jugador con la solucion
               almacenada en el puzle. La comparacion no distingue mayusculas
               de minusculas para mayor comodidad del jugador.
               Retornar� 1 si es correcta, 0 si no.
  Parametros : puzle     - puntero al puzle (entrada).
               respuesta - cadena con la respuesta del jugador (entrada).
 */
int comprobarSolucion(Puzle *puzle, char respuesta[]);

/*
 * Funcion    : validarPuzle
 * Descripcion: Comprueba la coherencia interna de un puzle: que los campos
 *              obligatorios no esten vacios, que el tipo sea "Codigo" o "Palabra"
 *              y que la solucion no este vacia.
 * Parametros : puzle - puntero al puzle a validar (entrada).
 * Retorno    : 1 (verdadero) si el puzle es valido, 0 (falso) en caso contrario.
 */
int validarPuzle(Puzle *puzle);

#endif /* PUZLES_H */
