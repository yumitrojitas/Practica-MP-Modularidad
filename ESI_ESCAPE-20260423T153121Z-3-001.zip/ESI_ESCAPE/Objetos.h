#ifndef OBJETOS_H
#define OBJETOS_H

#include "Estructuras.h"

//Constantes

#define TAM_ID_OBJ          4    //Id de los objetos
#define TAM_NOMB_OBJ       15    //15 caracteres
#define TAM_DESCRIB_OBJ    50    //50 caracteres
#define TAM_LOCALIZ        10    //El m�ximo tama�o es "Inventario"



//Declaraciones de funciones

/*
  Funcion    : buscarObjeto
  Descripcion: Busca un objeto por su identificador en la lista.
               Retorna el indice del objeto del array si se encuentra, -1 si no.
  Parametros : lista - lista de objetos (entrada).
               idObj - identificador del objeto buscado (entrada).
 */
int buscarObjeto(Objeto** lista_objetos, int total_objetos, char* idObj);

/*
  Funcion    : buscarObjetoEnSala
  Descripcion: Devuelve el indice del primer objeto cuya localizacion
               coincide con la sala indicada, y devuelve -1 si no lo encuentra.
  Parametros : lista  - lista de objetos (entrada).
               idSala - identificador de la sala (entrada).
 */
int buscarObjetoEnSala(Objeto** lista_objetos, int total_objetos, char* idSala);

/*
  Funcion    : estaEnInventario
  Descripcion: Indica si un objeto se encuentra actualmente en el inventario
               del jugador y devuelve 1 si si, 0 si no.
  Parametros : obj - puntero al objeto a consultar (entrada).
 */
int estaEnInventario(Objeto *obj);

/*
  Funcion    : moverObjetoASala
  Descripcion: Cambia la localizacion del objeto al identificador de sala
               indicado. No retorna nada
  Parametros : obj    - puntero al objeto a mover (entrada/salida).
               idSala - identificador de la sala destino (entrada).
 */
void moverObjetoASala(Objeto *obj, char* idSala);

/*
 * Funcion    : moverObjetoAInventario
 * Descripcion: Cambia la localizacion del objeto al Inventario. No retorna nada.
 * Parametros : obj - puntero al objeto a mover (entrada/salida).
 */
void moverObjetoAInventario(Objeto *obj);

/*
  Funcion    : mostrarObjeto
  Descripcion: Muestra por pantalla el identificador, nombre y descripcion
               del objeto. No retorna nada.
  Parametros : obj - puntero al objeto a mostrar (entrada).
 */
void mostrarObjeto(Objeto *obj);

/*
 * Funcion    : listarObjetosEnSala
 * Descripcion: Muestra por pantalla todos los objetos cuya localizacion
 *              coincide con la sala indicada. Si no hay ninguno, informa
 *              al jugador que no hay objetos en la sala. No retorna nada.
 * Parametros : lista  - lista de objetos (entrada).
 *              idSala - identificador de la sala (entrada).
 */
void listarObjetosEnSala(Objeto** lista, int num, int idSala);

/*
  Funcion    : listarInventario
  Descripcion: Muestra por pantalla todos los objetos que se encuentran
               en el inventario del jugador con su nombre y descripcion.
               Si el inventario esta vacio, informa al jugador. No retorna nada.
  Parametros : lista - lista de objetos (entrada).
 */
void listarInventario(Objeto** lista, int num);

/*
  Funcion    : validarObjeto
  Descripcion: Comprueba la coherencia interna de un objeto: que los campos
               obligatorios no esten vacios y que la localizacion sea v�lida.
               Devuelve 1 si lo es, 0 si no.
  Parametros : obj - puntero al objeto a validar (entrada).
 */
int validarObjeto(Objeto *obj);

#endif /* OBJETOS_H */
