#ifndef ACCIONES_H
#define ACCIONES_H

#include "Jugador.h"

// Declaraci�n de funciones

/*
  Funci�n:      hacer_login
  Descripcion:  Comprueba las credenciales de un usuario buscando
                coincidencias de nombre de usuario y contrase�a en el sistema.
  Par�metros:   lista_jugadores - array din�mico de jugadores (entrada)
                num_jugadores - entero con el total de jugadores (entrada)
                user - cadena de caracteres con el nombre del usuario (entrada)
                pass - cadena de caracteres con la contrase�a (entrada)
*/
Jugador* hacer_login(Jugador** lista_jugadores, int num_jugadores, char* user, char* pass);

/*
  Funci�n:      id_mayor
  Descripcion:  Recorre la lista de jugadores para
                encontrar el identificador ID m�s grande.
  Par�metros:   lista_jugadores - array din�mico de jugadores (entrada)
                num_jugadores - entero con el total de jugadores (entrada)
*/
int id_mayor(Jugador** lista_jugadores, int num_jugadores);

/*
  Funci�n:      guardar_partida
  Descripcion:  Guarda o actualiza el estado de la partida de un jugador,
                guardando la sala actual y el estado de los objetos, conexiones
                y puzles de la sesi�n.
  Par�metros:   jugador_actual - puntero al jugador actual (entrada)
                id_sala_actual - entero con la ID de la sala en la que se encuentra (entrada)
                lista_partidas - array din�mico de partidas del sistema (entrada)
                total_partidas - puntero al total de partidas registradas (entrada/salida)
                lista_objetos_activos - array din�mico de objetos en la sesi�n (entrada)
                total_obj - entero con el total de objetos en sesi�n (entrada)
                lista_conexiones_activas - array din�mico de conexiones en la sesi�n (entrada)
                total_con - entero con el total de conexiones en sesi�n (entrada)
                lista_puzles_activos - array din�mico de puzles en la sesi�n (entrada)
                total_puz - entero con el total de puzles en sesi�n (entrada)
*/
Partida** guardar_partida(Jugador* jugador_actual, int id_sala_actual, Partida** lista_partidas, int* total_partidas, Objeto** lista_objetos_activos, int total_obj, Conexion** lista_conexiones_activas, int total_con);

#endif // ACCIONES_H
