#ifndef FICHEROS_H
#define FICHEROS_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "Estructuras.h"


// Declaraci�n de funciones

/*
  Funci�n:      cargar_jugadores
  Descripcion:  Lee el fichero .txt donde esta guardada la
                informaci�n sobre los jugadores y la carga
                en el array dinamico que guardar� a los jugadores
  Par�metros:   ruta_fichero - cadena de caracteres (entrada)
                num_jugadores - puntero a entero con el total de jugadores (entrada/salida)
*/
Jugador** cargar_jugadores(char* ruta_fichero, int* num_jugadores);

/*
  Funci�n:      guardar_jugadores
  Descripcion:  Escribe la informaci�n del array din�mico de
                jugadores en el fichero .txt correspondiente
  Par�metros:   ruta_fichero - cadena de caracteres (entrada)
                lista_jugadores - array din�mico de jugadores (entrada)
                num_jugadores - entero con el total de jugadores (entrada)
*/
void guardar_jugadores(char* ruta_fichero, Jugador** lista_jugadores, int num_jugadores);

/*
  Funci�n:      destruir_lista_jugadores
  Descripcion:  Libera la memoria din�mica reservada para el array
                de jugadores y sus estructuras
  Par�metros:   lista_jugadores - array din�mico de jugadores (entrada)
                total_jugadores - entero con el total de jugadores (entrada)
*/
void destruir_lista_jugadores(Jugador** lista_jugadores, int total_jugadores);


/*
  Funci�n:      cargar_partidas
  Descripcion:  Lee el fichero .txt donde esta guardada la
                informaci�n sobre las partidas y la carga
                en el array din�mico que guardar� las partidas
  Par�metros:   ruta_fichero - cadena de caracteres (entrada)
                total_partidas - puntero al total de partidas (entrada/salida)
*/
Partida** cargar_partidas(char* ruta_fichero, int* total_partidas);

/*
  Funci�n:      guardar_partidas
  Descripcion:  Escribe la informaci�n del array din�mico de
                partidas en el fichero .txt correspondiente
  Par�metros:   ruta_fichero - cadena de caracteres (entrada)
                lista_partidas - array din�mico de partidas (entrada)
                total_partidas - entero con el total de partidas (entrada)
*/
void guardar_partidas(char* ruta_fichero, Partida** lista_partidas, int total_partidas);

/*
  Funci�n:      destruir_partidas
  Descripcion:  Libera la memoria din�mica reservada para el array
                de partidas y sus estructuras internas
  Par�metros:   lista_partidas - array din�mico de partidas (entrada)
                total_partidas - entero con el total de partidas (entrada)
*/
void destruir_partidas(Partida** lista_partidas, int total_partidas);


/*
  Funci�n:      cargar_salas
  Descripcion:  Lee el fichero .txt donde esta guardada la
                informaci�n sobre las salas y la carga
                en un array din�mico que contendr� las salas
  Par�metros:   ruta_fichero - cadena de caracteres (entrada)
                total_salas - puntero al total de salas (entrada/salida)
*/
Sala** cargar_salas(char* ruta_fichero, int* total_salas);

/*
  Funci�n:      destruir_lista_salas
  Descripcion:  Libera la memoria din�mica reservada para el array
                de salas
  Par�metros:   lista_salas - array din�mico de salas (entrada)
                total_salas - entero con el total de salas (entrada)
*/
void destruir_lista_salas(Sala** lista_salas, int total_salas);


/*
  Funci�n:      cargar_conexiones
  Descripcion:  Lee el fichero .txt donde esta guardada la
                informaci�n sobre las conexiones y la carga
                en un array din�mico
  Par�metros:   ruta_fichero - cadena de caracteres (entrada)
                total_conexiones - puntero al total de conexiones (entrada/salida)
*/
Conexion** cargar_conexiones(char* ruta_fichero, int* total_conexiones);

/*
  Funci�n:      destruir_lista_conexiones
  Descripcion:  Libera la memoria din�mica reservada para el array
                de conexiones
  Par�metros:   lista_conexiones - array din�mico de conexiones (entrada)
                total_conexiones - entero con el total de conexiones (entrada)
*/
void destruir_lista_conexiones(Conexion** lista_conexiones, int total_conexiones);


/*
  Funci�n:      cargar_objetos
  Descripcion:  Lee el fichero .txt donde esta guardada la
                informaci�n sobre los objetos y la carga
                en un array din�mico
  Par�metros:   ruta_fichero - cadena de caracteres (entrada)
                total_objetos - puntero al total de objetos (entrada/salida)
*/
Objeto** cargar_objetos(char* ruta_fichero, int* total_objetos);

/*
  Funci�n:      destruir_lista_objetos
  Descripcion:  Libera la memoria din�mica reservada para el array
                de objetos
  Par�metros:   lista_objetos - array din�mico de objetos (entrada)
                total_objetos - entero con el total de objetos (entrada)
*/
void destruir_lista_objetos(Objeto** lista_objetos, int total_objetos);


/*
  Funci�n:      cargar_puzles
  Descripcion:  Lee el fichero .txt donde esta guardada la
                informaci�n sobre los puzles y la carga
                en un array din�mico
  Par�metros:   ruta_fichero - cadena de caracteres (entrada)
                total_puzles - puntero al total de puzles (entrada/salida)
*/
Puzle** cargar_puzles(char* ruta_fichero, int* total_puzles);

/*
  Funci�n:      destruir_lista_puzles
  Descripcion:  Libera la memoria din�mica reservada para el array
                de puzles
  Par�metros:   lista_puzles - array din�mico de puzles (entrada)
                total_puzles - entero con el total de puzles (entrada)
*/
void destruir_lista_puzles(Puzle** lista_puzles, int total_puzles);
#endif // FICHEROS_H
