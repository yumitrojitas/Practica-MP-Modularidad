#ifndef FLUJO_PARTIDA_H
#define FLUJO_PARTIDA_H

#include "Ficheros.h"
#include "Acciones.h"
#include "Salas.h"
#include "Objetos.h"
#include "Puzles.h"

void ejecutar_flujo_juego(Jugador* jugador_actual, Sala** lista_salas, int total_salas, Objeto** lista_objetos, int total_objetos, Puzle** lista_puzles, int total_puzles, Conexion** lista_conexiones, int total_conexiones, Partida** lista_partidas, int* total_partidas, int es_nueva_partida);

#endif /* FLUJO_PARTIDA_H */
